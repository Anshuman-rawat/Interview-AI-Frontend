import React, { useState } from 'react';
import '../style/home.scss';
import { generateInterviewReport } from '../../services/interview.api'

const Home = () => {
  const [jobDescription, setJobDescription] = useState("")
  const [selfDescription, setSelfDescription] = useState("")
  const [resume, setResume] = useState(null)
  const [loading, setLoading] = useState(false)
  const [report, setReport] = useState(null)

  const handleGenerate = async () => {
    setLoading(true)
    try {
      const data = await generateInterviewReport({ resume, jobDescription, selfDescription })
      setReport(data.interviewReport)
    } catch (err) {
      console.error("Failed to generate report:", err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className='home-page'>
      <div className='app-shell'>
        <header className='browser-bar'>
          <div className='browser-left'>
            <span className='dot red'></span>
            <span className='dot yellow'></span>
            <span className='dot green'></span>
          </div>
          <div className='browser-center'>
            <span className='browser-label'>red output | Gemini 4.1</span>
            <span className='browser-pill'>frontend</span>
          </div>
          <div className='browser-actions'>
            <span>⟳</span>
            <span>＋</span>
            <span>⋯</span>
          </div>
        </header>

        <section className='hero'>
          <h1>
            Create Your Custom <span>Interview Plan</span>
          </h1>
          <p>
            Let our AI analyze the job requirements and your unique profile to
            build a winning strategy.
          </p>
        </section>

        <section className='panel-grid'>
          <div className='panel left-panel'>
            <div className='panel-header'>
              <div className='title-wrap'>
                <span className='panel-icon'>🗂</span>
                <span>Target Job Description</span>
              </div>
              <span className='badge required'>REQUIRED</span>
            </div>

            <textarea
              className='job-textarea'
              aria-label='Job description'
              placeholder='Paste the full job description here...'
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
            />

            <div className='char-counter'>{jobDescription.length} / 5000 chars</div>
          </div>

          <div className='panel right-panel'>
            <div className='panel-header'>
              <div className='title-wrap'>
                <span className='panel-icon'>👤</span>
                <span>Your Profile</span>
              </div>
              <span className='badge secondary'>BEST RESULTS</span>
            </div>

            <label className='upload-box' htmlFor='resume-upload'>
              <span className='upload-icon'>⇪</span>
              <span className='upload-label'>
                {resume ? resume.name : "Click to upload or drag & drop"}
              </span>
              <small>PDF or DOCX (Max 5MB)</small>
              <input
                hidden
                type='file'
                id='resume-upload'
                accept='.pdf,.doc,.docx'
                onChange={(e) => setResume(e.target.files[0])}
              />
            </label>

            <div className='divider'>OR</div>

            <div className='textarea-block'>
              <label htmlFor='self-description'>Quick Self-Description</label>
              <textarea
                id='self-description'
                placeholder='Briefly describe your experience, key skills...'
                value={selfDescription}
                onChange={(e) => setSelfDescription(e.target.value)}
              />
            </div>

            <div className='info-banner'>
              <span className='info-icon'>i</span>
              <span>
                Either a Resume or a Self Description <strong>is required</strong>{' '}
                to generate a personalized plan.
              </span>
            </div>
          </div>
        </section>

        <div className='cta-row'>
          <div className='generation-note'>AI-Powered Strategy Generation · Approx 30s</div>
          <button className='generate-btn' type='button' onClick={handleGenerate} disabled={loading}>
            <span className='star'>✦</span> {loading ? "Generating..." : "Generate My Interview Strategy"}
          </button>
        </div>

        {report && (
          <pre style={{ color: "white", whiteSpace: "pre-wrap" }}>
            {JSON.stringify(report, null, 2)}
          </pre>
        )}

        <footer className='page-footer'>
          <a href='#'>Privacy Policy</a>
          <a href='#'>Terms of Service</a>
          <a href='#'>Help Center</a>
        </footer>
      </div>
    </main>
  );
};

export default Home